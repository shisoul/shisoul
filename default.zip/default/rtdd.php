<div class="align-items-center justify-content-between mb-0" id="iframeWrapper" style="height:1500px">
    <iframe class="mt-75" src="/rtdd/screen" width="100%" height="100%" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" loading="lazy" id="myIframe"></iframe>
</div>
<style>
    .footer-style-four {
        background: #fff;
    }

    .tb-contacts {
        display: none;
    }
</style>